<?php 
	$host = "localhost";
	$user = "root";
	$password = "";
	$db = "db_cbt";

	$con = mysqli_connect($host, $user, $password, $db);
 ?>